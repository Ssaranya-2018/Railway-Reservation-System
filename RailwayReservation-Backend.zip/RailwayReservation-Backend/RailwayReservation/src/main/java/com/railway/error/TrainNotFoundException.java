package com.railway.error;

public class TrainNotFoundException extends Exception {

	public TrainNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
