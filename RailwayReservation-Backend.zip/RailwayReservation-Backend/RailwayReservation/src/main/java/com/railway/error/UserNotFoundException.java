package com.railway.error;

public class UserNotFoundException extends Exception{
	public UserNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}


